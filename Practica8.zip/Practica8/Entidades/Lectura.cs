﻿namespace Practica8.Entidades
{
    public class Lectura
    {
        public int Id { get; set; }
        public string FechaHora { get; set; }
        public string IdDispositivo { get; set; }
        public string Sensor { get; set; }
        public float Valor { get; set; }
    }
}

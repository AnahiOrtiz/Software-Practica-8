﻿using Practica8.Entidades;
using RestSharp;

namespace Practica8.Servicios
{
    public class DAL
    {
        public async Task<List<Lectura>> TraerDatos()
        {
            var cliente = new RestClient("http://dnsiteshu.centralus.cloudapp.azure.com/php-crud-api/api.php/records");
            var peticion = new RestRequest("Lectura", Method.Get);
            var respuesta = await cliente.GetAsync<Root>(peticion).ConfigureAwait(false);
            return respuesta.records;
            
        }
    }
}